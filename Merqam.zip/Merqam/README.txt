Merqam - طريقة التشغيل
1) افتحي Android Studio > Open > اختاري فولدر Merqam (ولو سألك عن Gradle دوسي OK/Trust).
2) استني الـ Sync يخلص (محتاج نت أول مرة).
3) وصّلي التابلت بكابل USB وفعّلي Developer options > USB debugging.
4) دوسي Run (▶) والتطبيق هيتنصب على التابلت.
ولو عايزة ملف APK: Build > Build APK(s).
