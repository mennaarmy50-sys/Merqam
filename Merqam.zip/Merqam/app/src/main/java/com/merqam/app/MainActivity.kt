package com.merqam.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

// ---------- Model ----------
sealed class Elem
data class StrokeE(val pts: List<Offset>, val color: Color, val w: Float, val a: Float) : Elem()
data class ShapeE(val type: String, val a: Offset, val b: Offset, val color: Color, val w: Float) : Elem()
data class StickerE(val t: String, val pos: Offset) : Elem()
data class ImageE(val bmp: ImageBitmap, val pos: Offset, val uri: Uri?, val video: Boolean) : Elem()

class PageState {
    val elems = mutableStateListOf<Elem>()
    private val redoStack = mutableListOf<Elem>()
    fun add(e: Elem) { elems.add(e); redoStack.clear() }
    fun undo() { if (elems.isNotEmpty()) redoStack.add(elems.removeAt(elems.lastIndex)) }
    fun redo() { if (redoStack.isNotEmpty()) elems.add(redoStack.removeAt(redoStack.lastIndex)) }
}

enum class Tool { PEN, HL, ERASE, MOVE, SHAPE }

fun hit(e: Elem, p: Offset): Boolean = when (e) {
    is StickerE -> (p - e.pos).getDistance() < 70f
    is ImageE -> p.x in e.pos.x..(e.pos.x + e.bmp.width) && p.y in e.pos.y..(e.pos.y + e.bmp.height)
    else -> false
}

fun near(e: Elem, p: Offset, r: Float): Boolean = when (e) {
    is StrokeE -> e.pts.any { (it - p).getDistance() < r }
    is ShapeE -> p.x in (min(e.a.x, e.b.x) - r)..(max(e.a.x, e.b.x) + r) &&
        p.y in (min(e.a.y, e.b.y) - r)..(max(e.a.y, e.b.y) + r)
    else -> hit(e, p)
}

// ---------- Drawing ----------
fun DrawScope.drawStroke(pts: List<Offset>, c: Color, w: Float, a: Float) {
    if (pts.isEmpty()) return
    if (pts.size == 1) { drawCircle(c.copy(alpha = a), w / 2, pts[0]); return }
    val p = Path()
    p.moveTo(pts[0].x, pts[0].y)
    for (i in 1 until pts.size) {
        val m = (pts[i - 1] + pts[i]) / 2f
        p.quadraticBezierTo(pts[i - 1].x, pts[i - 1].y, m.x, m.y)
    }
    drawPath(p, c.copy(alpha = a), style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

fun DrawScope.drawShapeE(type: String, a: Offset, b: Offset, c: Color, w: Float) {
    val tl = Offset(min(a.x, b.x), min(a.y, b.y))
    val sz = Size(abs(a.x - b.x), abs(a.y - b.y))
    val st = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (type) {
        "line" -> drawLine(c, a, b, w, StrokeCap.Round)
        "arrow" -> {
            drawLine(c, a, b, w, StrokeCap.Round)
            val ang = atan2(b.y - a.y, b.x - a.x)
            for (s in listOf(-1f, 1f)) {
                val t2 = ang + PI.toFloat() + s * 0.5f
                drawLine(c, b, Offset(b.x + 40f * cos(t2), b.y + 40f * sin(t2)), w, StrokeCap.Round)
            }
        }
        "rect" -> drawRect(c, tl, sz, style = st)
        "oval" -> drawOval(c, tl, sz, style = st)
        else -> {
            val p = Path().apply {
                moveTo(tl.x + sz.width / 2, tl.y); lineTo(tl.x + sz.width, tl.y + sz.height)
                lineTo(tl.x, tl.y + sz.height); close()
            }
            drawPath(p, c, style = st)
        }
    }
}

@Composable
fun Board(
    page: PageState, tool: Tool, color: Color, width: Float, shape: String,
    stylusOnly: Boolean, onOpen: (Uri) -> Unit, modifier: Modifier = Modifier
) {
    val cur = remember { mutableStateListOf<Offset>() }
    var pa by remember { mutableStateOf<Offset?>(null) }
    var pb by remember { mutableStateOf<Offset?>(null) }
    val paint = remember {
        android.graphics.Paint().apply { textSize = 96f; textAlign = android.graphics.Paint.Align.CENTER }
    }
    fun erase(p: Offset) { page.elems.removeAll { near(it, p, 28f) } }

    Canvas(
        modifier.background(Color.White).pointerInput(tool, stylusOnly, color, width, shape) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                if (stylusOnly && down.type == PointerType.Touch) return@awaitEachGesture
                var last = down.position
                var moved = 0f
                var idx = -1
                when (tool) {
                    Tool.PEN, Tool.HL -> { cur.clear(); cur.add(last) }
                    Tool.SHAPE -> { pa = last; pb = last }
                    Tool.ERASE -> erase(last)
                    Tool.MOVE -> idx = page.elems.indexOfLast { hit(it, last) }
                }
                while (true) {
                    val ev = awaitPointerEvent()
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!ch.pressed) break
                    val p = ch.position
                    when (tool) {
                        Tool.PEN, Tool.HL -> cur.add(p)
                        Tool.SHAPE -> pb = p
                        Tool.ERASE -> erase(p)
                        Tool.MOVE -> if (idx >= 0) {
                            val d = p - last
                            moved += d.getDistance()
                            val el = page.elems[idx]
                            page.elems[idx] = when (el) {
                                is StickerE -> el.copy(pos = el.pos + d)
                                is ImageE -> el.copy(pos = el.pos + d)
                                else -> el
                            }
                        }
                    }
                    last = p
                    ch.consume()
                }
                when (tool) {
                    Tool.PEN -> if (cur.isNotEmpty()) page.add(StrokeE(cur.toList(), color, width, 1f))
                    Tool.HL -> if (cur.isNotEmpty()) page.add(StrokeE(cur.toList(), color, width * 4, 0.35f))
                    Tool.SHAPE -> { val a = pa; val b = pb; if (a != null && b != null) page.add(ShapeE(shape, a, b, color, width)) }
                    Tool.MOVE -> if (moved < 12f && idx >= 0) {
                        val el = page.elems[idx]
                        if (el is ImageE && el.video && el.uri != null) onOpen(el.uri)
                    }
                    else -> {}
                }
                cur.clear(); pa = null; pb = null
            }
        }
    ) {
        var y = 60
        while (y < size.height) {
            drawLine(Color(0xFFE3E8EF), Offset(0f, y.toFloat()), Offset(size.width, y.toFloat()), 1f)
            y += 60
        }
        for (e in page.elems) when (e) {
            is StrokeE -> drawStroke(e.pts, e.color, e.w, e.a)
            is ShapeE -> drawShapeE(e.type, e.a, e.b, e.color, e.w)
            is StickerE -> drawContext.canvas.nativeCanvas.drawText(e.t, e.pos.x, e.pos.y + 34f, paint)
            is ImageE -> {
                drawImage(e.bmp, e.pos)
                if (e.video) {
                    val c = Offset(e.pos.x + e.bmp.width / 2f, e.pos.y + e.bmp.height / 2f)
                    drawCircle(Color(0x99000000), 50f, c)
                    val tri = Path().apply { moveTo(c.x - 15, c.y - 25); lineTo(c.x + 28, c.y); lineTo(c.x - 15, c.y + 25); close() }
                    drawPath(tri, Color.White)
                }
            }
        }
        val hl = tool == Tool.HL
        drawStroke(cur.toList(), color, if (hl) width * 4 else width, if (hl) 0.35f else 1f)
        val a = pa; val b = pb
        if (a != null && b != null) drawShapeE(shape, a, b, color, width)
    }
}

// ---------- Calculator ----------
class Calc(private val s: String) {
    private var i = 0
    fun eval(): Double { val v = expr(); if (i < s.length) error("x"); return v }
    private fun expr(): Double {
        var v = term()
        while (i < s.length) when (s[i]) { '+' -> { i++; v += term() } '-' -> { i++; v -= term() } else -> break }
        return v
    }
    private fun term(): Double {
        var v = pow()
        while (i < s.length) when (s[i]) { '*' -> { i++; v *= pow() } '/' -> { i++; v /= pow() } else -> break }
        return v
    }
    private fun pow(): Double {
        val b = unary()
        if (i < s.length && s[i] == '^') { i++; return b.pow(pow()) }
        return b
    }
    private fun unary(): Double { if (i < s.length && s[i] == '-') { i++; return -unary() }; return atom() }
    private fun atom(): Double {
        if (i >= s.length) error("x")
        if (s[i] == '(') { i++; val v = expr(); if (i < s.length && s[i] == ')') i++; return v }
        if (s[i].isDigit() || s[i] == '.') {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            return s.substring(st, i).toDouble()
        }
        val st = i
        while (i < s.length && s[i].isLetter()) i++
        val n = s.substring(st, i)
        if (n == "pi") return PI
        val x = atom()
        return when (n) {
            "sin" -> sin(Math.toRadians(x)); "cos" -> cos(Math.toRadians(x)); "tan" -> tan(Math.toRadians(x))
            "sqrt" -> sqrt(x); "log" -> log10(x); "ln" -> ln(x); else -> error("x")
        }
    }
}

@Composable
fun CalcDialog(onClose: () -> Unit) {
    var ex by remember { mutableStateOf("") }
    val res = runCatching { Calc(ex).eval() }.getOrNull()
    val keys = listOf(
        listOf("sin(", "cos(", "tan(", "sqrt("), listOf("log(", "ln(", "pi", "^"),
        listOf("(", ")", "C", "/"), listOf("7", "8", "9", "*"), listOf("4", "5", "6", "-"),
        listOf("1", "2", "3", "+"), listOf("0", ".", "<", "")
    )
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("إغلاق") } },
        text = {
            Column {
                Text(ex.ifEmpty { "0" }, fontSize = 22.sp)
                Text(if (ex.isEmpty()) "" else if (res == null) "…" else "= " + (if (res % 1.0 == 0.0 && abs(res) < 1e12) res.toLong().toString() else "%.6f".format(res).trimEnd('0').trimEnd('.')), fontSize = 28.sp)
                keys.forEach { row ->
                    Row { row.forEach { k ->
                        if (k.isEmpty()) Spacer(Modifier.weight(1f)) else
                            TextButton(onClick = { ex = when (k) { "C" -> ""; "<" -> ex.dropLast(1); else -> ex + k } }, modifier = Modifier.weight(1f)) { Text(k, fontSize = 15.sp) }
                    } }
                }
            }
        }
    )
}

// ---------- UI ----------
@Composable
fun Tb(l: String, sel: Boolean = false, on: () -> Unit) {
    Box(
        Modifier.padding(2.dp).background(if (sel) Color(0xFFD0E4FF) else Color(0xFFF1F1F1), RoundedCornerShape(8.dp))
            .clickable(onClick = on).padding(horizontal = 10.dp, vertical = 8.dp)
    ) { Text(l, fontSize = 16.sp) }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val pages = remember { mutableStateListOf(PageState()) }
    var pi by remember { mutableIntStateOf(0) }
    val side = remember { PageState() }
    val strip = remember { PageState() }
    var cursorY by remember { mutableStateOf(80f) }
    var tool by remember { mutableStateOf(Tool.PEN) }
    var color by remember { mutableStateOf(Color.Black) }
    var width by remember { mutableStateOf(6f) }
    var shape by remember { mutableStateOf("line") }
    var stylusOnly by remember { mutableStateOf(false) }
    var showSide by remember { mutableStateOf(false) }
    var showStrip by remember { mutableStateOf(false) }
    var showCalc by remember { mutableStateOf(false) }
    var showStickers by remember { mutableStateOf(false) }
    val page = pages[pi]

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val video = ctx.contentResolver.getType(uri)?.startsWith("video") == true
            val raw: Bitmap? = if (video) {
                runCatching {
                    val r = MediaMetadataRetriever(); r.setDataSource(ctx, uri)
                    r.getFrameAtTime(0).also { r.release() }
                }.getOrNull()
            } else ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            if (raw != null) {
                val sc = 600f / max(raw.width, raw.height)
                val bmp = Bitmap.createScaledBitmap(raw, max(1, (raw.width * sc).toInt()), max(1, (raw.height * sc).toInt()), true)
                page.add(ImageE(bmp.asImageBitmap(), Offset(100f, 100f), uri, video))
            }
        }
    }
    val openVideo: (Uri) -> Unit = { u ->
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFFFAFAFA)).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Tb("✏️", tool == Tool.PEN) { tool = Tool.PEN }
            Tb("🖍", tool == Tool.HL) { tool = Tool.HL }
            Tb("🧽", tool == Tool.ERASE) { tool = Tool.ERASE }
            Tb("✋", tool == Tool.MOVE) { tool = Tool.MOVE }
            Tb("🔷", tool == Tool.SHAPE) { tool = Tool.SHAPE }
            if (tool == Tool.SHAPE) listOf("line" to "╱", "arrow" to "→", "rect" to "▭", "oval" to "◯", "tri" to "△").forEach { (k, l) ->
                Tb(l, shape == k) { shape = k }
            }
            listOf(Color.Black, Color(0xFFD32F2F), Color(0xFF1565C0), Color(0xFF2E7D32), Color(0xFFF57C00), Color(0xFF6A1B9A)).forEach { c ->
                Box(Modifier.padding(4.dp).size(if (c == color) 32.dp else 26.dp).clip(CircleShape).background(c).clickable { color = c })
            }
            Tb("S", width == 3f) { width = 3f }; Tb("M", width == 6f) { width = 6f }; Tb("L", width == 14f) { width = 14f }
            Tb("↶") { page.undo() }; Tb("↷") { page.redo() }
            Tb("🖊 قلم فقط", stylusOnly) { stylusOnly = !stylusOnly }
            Tb("🖼") { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }
            Tb("😀") { showStickers = true }
            Tb("🧮") { showCalc = true }
            Tb("📋 سبورة", showSide) { showSide = !showSide }
            Tb("⌨ نافذة كتابة", showStrip) { showStrip = !showStrip }
            Tb("◀") { if (pi > 0) pi-- }
            Text("${pi + 1}/${pages.size}", Modifier.padding(4.dp))
            Tb("▶") { if (pi < pages.size - 1) pi++ }
            Tb("＋") { pages.add(PageState()); pi = pages.size - 1 }
            Tb("🗑") { page.elems.clear() }
        }
        Row(Modifier.weight(1f).fillMaxWidth()) {
            key(pi) { Board(page, tool, color, width, shape, stylusOnly, openVideo, Modifier.weight(1f).fillMaxHeight()) }
            if (showSide) {
                Spacer(Modifier.width(4.dp))
                Column(Modifier.weight(0.4f).fillMaxHeight()) {
                    Row { Text("السبورة الجانبية", Modifier.padding(4.dp).weight(1f)); Tb("مسح") { side.elems.clear() } }
                    Board(side, tool, color, width, shape, stylusOnly, openVideo, Modifier.weight(1f).fillMaxWidth())
                }
            }
        }
        if (showStrip) Row(Modifier.fillMaxWidth().height(150.dp), verticalAlignment = Alignment.CenterVertically) {
            Board(strip, Tool.PEN, color, width, shape, stylusOnly, openVideo, Modifier.weight(1f).fillMaxHeight())
            Tb("↵ إدراج") {
                strip.elems.filterIsInstance<StrokeE>().forEach { s ->
                    page.add(s.copy(pts = s.pts.map { Offset(it.x * 0.3f + 40f, it.y * 0.3f + cursorY) }, w = s.w * 0.5f))
                }
                strip.elems.clear(); cursorY += 70f
            }
        }
    }
    if (showCalc) CalcDialog { showCalc = false }
    if (showStickers) AlertDialog(
        onDismissRequest = { showStickers = false },
        confirmButton = { TextButton(onClick = { showStickers = false }) { Text("إغلاق") } },
        text = {
            Column {
                "⭐❤️👍😀🎯📌✅❓💡🔥📚✏️🎓🌟📝🧠⚡🏆🙂🎉".codePoints().toArray().map { String(Character.toChars(it)) }
                    .let { l -> mergeEmoji(l) }.chunked(6).forEach { row ->
                        Row { row.forEach { e -> Text(e, fontSize = 32.sp, modifier = Modifier.padding(6.dp).clickable {
                            page.add(StickerE(e, Offset(300f + page.elems.size * 12f, 300f))); showStickers = false
                        }) } }
                    }
            }
        }
    )
}

// يدمج علامات التنويع (variation selector) مع الإيموجي اللي قبلها
fun mergeEmoji(l: List<String>): List<String> {
    val out = ArrayList<String>()
    for (s in l) if (s == "\uFE0F" && out.isNotEmpty()) out[out.lastIndex] = out.last() + s else out.add(s)
    return out
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}
